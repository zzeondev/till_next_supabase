function PostPage() {
  return <div>PostPage</div>;
}

export default PostPage;
