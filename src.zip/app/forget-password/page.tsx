function ForgetPassword() {
  return <div>ForgetPassword</div>;
}

export default ForgetPassword;
